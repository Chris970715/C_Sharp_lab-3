﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibInterface;

namespace LibCircuit
{
    public class Node : ILogic
    {
        private bool? m_output = null;
        private readonly ILogic m_input;

        public Node(ILogic Input)
        {
            m_input = Input;
        }

        public bool Output
        {
            get
            {
                if (!m_output.HasValue)
                    m_output = m_input.Output;
                return m_output.Value;
            }
        }
    }
}
