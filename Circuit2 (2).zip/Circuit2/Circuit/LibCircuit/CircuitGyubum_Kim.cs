﻿using LibInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCircuit
{
    public class CircuitGyubum_Kim : ILogic
    {
        private readonly IInputFactory inputFactory;
        private readonly IGateFactory gateFactory;

        public CircuitGyubum_Kim(IInputFactory inputFactory, IGateFactory gateFactory)
        {
            this.inputFactory = inputFactory;
            this.gateFactory = gateFactory;
        }

        public bool Output
        {
            get
            {
                ILogic inputA = inputFactory.CreateInput(1);
                ILogic inputB = inputFactory.CreateInput(2);
                ILogic inputC = inputFactory.CreateInput(3);
                ILogic inputD = inputFactory.CreateInput(4);
                ILogic inputE = inputFactory.CreateInput(5);
                ILogic inputF = inputFactory.CreateInput(6);

                ILogic andGate = gateFactory.CreateAndGate(inputA, inputB);
                ILogic OrGate = gateFactory.CreateOrGate(inputC, inputD);
                ILogic node1 = gateFactory.CreateNode(OrGate);
                ILogic andGate_2 = gateFactory.CreateAndGate(andGate,node1);
                ILogic OrGate_2 = gateFactory.CreateOrGate(node1,inputE);
                ILogic invert = gateFactory.CreateInverterGate(inputF);
                ILogic andGate_3 = gateFactory.CreateAndGate(OrGate_2,invert);
                ILogic result = gateFactory.CreateOrGate(andGate_2, andGate_3);

                return result.Output;
            }
        }
    }
}
