﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibInterface;

namespace LibCircuit
{
    // Class represents an input from a UI source
    public class Input : ILogic
    {
        public int InputNo { get; } // Input number for the input

        private Func<int, bool> UIInput { get; }

        public bool Output => UIInput(InputNo); // Produces an output from the input (ILogic.Output)

        public Input(int InputNo, Func<int, bool> UIInput)
        {
            this.InputNo = InputNo;
            this.UIInput = UIInput;
        }
    }
}
