﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibInterface;

namespace LibCircuit
{
    public class InputFactory : IInputFactory
    {
        private readonly Func<int, bool> m_UIInput; // Callback function for UI input

        public InputFactory(Func<int, bool> UIInput) => m_UIInput = UIInput;

        public ILogic CreateInput(int InputNo) => new Input(InputNo, m_UIInput);
    }
}
