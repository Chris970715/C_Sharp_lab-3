﻿using LibInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCircuit
{
    internal class Inverter : ILogic
    {
        private readonly ILogic m_input1;

        public Inverter(ILogic Input1)
        {
            m_input1 = Input1;
            
        }

        public bool Output => !m_input1.Output;
    }
}
