﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibInterface;

namespace LibCircuit
{
    public class GateFactory : IGateFactory
    {
        public ILogic CreateNode(ILogic Input) => new Node(Input);
        public ILogic CreateAndGate(ILogic Input1, ILogic Input2) => new AndGate(Input1, Input2);
        public ILogic CreateOrGate(ILogic Input1, ILogic Input2) => new OrGate(Input1, Input2);

        public ILogic CreateInverterGate(ILogic Input1) => new Inverter(Input1);

    }
}
