﻿using LibInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCircuit
{
    public class Circuit1 : ILogic
    {
        private readonly IInputFactory m_inputFactory;

        public Circuit1(IInputFactory InputFactory)
        {
            m_inputFactory = InputFactory;
        }

        // Simple circuit were input1 -------------> output
        public bool Output
        {
            get
            {
                ILogic input = m_inputFactory.CreateInput(1);
                return input.Output;
            }
        }
    }
}
