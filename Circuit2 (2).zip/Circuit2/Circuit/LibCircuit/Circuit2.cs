﻿using LibInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCircuit
{
    public class Circuit2 : ILogic
    {
        private readonly IInputFactory m_inputFactory;
        private readonly IGateFactory m_gateFactory;

        public Circuit2(IInputFactory InputFactory, IGateFactory GateFactory)
        {
            m_inputFactory = InputFactory;
            m_gateFactory = GateFactory;
        }

        // input2 ---> node1 | input1, node1 ---> and1 | node1, input3 ---> and2 | and1, and2 ---> and3 | and3 ---> output
        public bool Output
        {
            get
            {
                ILogic input1 = m_inputFactory.CreateInput(1);
                ILogic input2 = m_inputFactory.CreateInput(2);
                ILogic node1 = m_gateFactory.CreateNode(input2);
                ILogic and1 = m_gateFactory.CreateAndGate(input1, node1);
                ILogic input3 = m_inputFactory.CreateInput(3);
                ILogic and2 = m_gateFactory.CreateAndGate(node1, input3);
                ILogic and3 = m_gateFactory.CreateAndGate(and1, and2);
                return and3.Output;
            }
        }
    }
}
