﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibInterface
{
    // This interface represents a factory class to create an Input
    public interface IInputFactory
    {
        ILogic CreateInput(int InputNo);
    }
}
