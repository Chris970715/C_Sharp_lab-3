﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibInterface
{
    // This interface represents a component that returns a logic output
    public interface ILogic
    {
        bool Output { get; }
    }
}
