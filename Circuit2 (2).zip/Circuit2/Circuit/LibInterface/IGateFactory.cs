﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibInterface
{
    public interface IGateFactory
    {
        ILogic CreateNode(ILogic Input);
        ILogic CreateAndGate(ILogic Input1, ILogic Input2);

        ILogic CreateOrGate(ILogic Input1, ILogic Input2);

        ILogic CreateInverterGate(ILogic Input1);
    }
}
